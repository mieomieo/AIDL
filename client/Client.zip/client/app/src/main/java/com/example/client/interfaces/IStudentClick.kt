package interfaces

import com.example.server.Student

interface IStudentClick {
    fun handleEditStudent(student: Student)
}